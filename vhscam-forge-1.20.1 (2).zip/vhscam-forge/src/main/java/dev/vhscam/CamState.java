package dev.vhscam;

public class CamState {
    public static boolean active = false;
    public static boolean recording = false;
    public static boolean longPlay = false;
    public static long recStartMs = 0;
    public static long recAccumMs = 0;
    public static char tape = 'A';
    public static float zoom = 1.0f;
    public static final float MAX_ZOOM = 8.0f;

    public static void pause() {
        if (recording) recAccumMs += System.currentTimeMillis() - recStartMs;
        recording = false;
    }

    public static long elapsedMs() {
        return recAccumMs + (recording ? System.currentTimeMillis() - recStartMs : 0);
    }
}
