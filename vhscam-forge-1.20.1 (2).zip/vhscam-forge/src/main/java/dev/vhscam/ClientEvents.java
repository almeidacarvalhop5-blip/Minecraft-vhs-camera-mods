package dev.vhscam;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

public class ClientEvents {
    public static final String CAT = "key.category.vhscam";
    public static final KeyMapping TOGGLE = new KeyMapping("key.vhscam.toggle", GLFW.GLFW_KEY_V, CAT);
    public static final KeyMapping REC    = new KeyMapping("key.vhscam.rec", GLFW.GLFW_KEY_R, CAT);
    public static final KeyMapping ZOOM_IN  = new KeyMapping("key.vhscam.zoom_in", GLFW.GLFW_KEY_UP, CAT);
    public static final KeyMapping ZOOM_OUT = new KeyMapping("key.vhscam.zoom_out", GLFW.GLFW_KEY_DOWN, CAT);
    public static final KeyMapping TAPE   = new KeyMapping("key.vhscam.tape", GLFW.GLFW_KEY_B, CAT);
    public static final KeyMapping SPEED  = new KeyMapping("key.vhscam.speed", GLFW.GLFW_KEY_N, CAT);

    // Barramento do mod: registro das teclas
    @Mod.EventBusSubscriber(modid = VhsCam.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static class ModBus {
        @SubscribeEvent
        public static void onKeys(RegisterKeyMappingsEvent e) {
            e.register(TOGGLE);
            e.register(REC);
            e.register(ZOOM_IN);
            e.register(ZOOM_OUT);
            e.register(TAPE);
            e.register(SPEED);
        }
    }

    // Barramento do Forge: tick, HUD e FOV
    @Mod.EventBusSubscriber(modid = VhsCam.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
    public static class ForgeBus {
        @SubscribeEvent
        public static void onTick(TickEvent.ClientTickEvent e) {
            if (e.phase != TickEvent.Phase.END) return;
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null) { CamState.active = false; CamState.recording = false; return; }

            while (TOGGLE.consumeClick()) {
                CamState.active = !CamState.active;
                if (!CamState.active) CamState.pause();
            }
            if (!CamState.active) return;

            while (REC.consumeClick()) {
                if (CamState.recording) CamState.pause();
                else { CamState.recording = true; CamState.recStartMs = System.currentTimeMillis(); }
            }
            while (TAPE.consumeClick()) {
                if (!CamState.recording) {
                    CamState.tape = (char) (CamState.tape >= 'D' ? 'A' : CamState.tape + 1);
                    CamState.recAccumMs = 0;
                }
            }
            while (SPEED.consumeClick()) CamState.longPlay = !CamState.longPlay;

            if (ZOOM_IN.isDown())  CamState.zoom = Math.min(CamState.MAX_ZOOM, CamState.zoom + 0.05f);
            if (ZOOM_OUT.isDown()) CamState.zoom = Math.max(1.0f, CamState.zoom - 0.05f);
        }

        // Esconde o HUD do jogo e desenha so o viewfinder
        @SubscribeEvent
        public static void onGui(RenderGuiEvent.Pre e) {
            if (!CamState.active) return;
            VhsOverlay.render(e.getGuiGraphics());
            e.setCanceled(true);
        }

        @SubscribeEvent
        public static void onFov(ViewportEvent.ComputeFov e) {
            if (CamState.active) e.setFOV(e.getFOV() / CamState.zoom);
        }
    }
}
