package dev.vhscam;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;

public class VhsOverlay {
    private static final Random RNG = new Random();
    private static final int WHITE = 0xFFE8E8F0;
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("yyyy-MM-dd  HH:mm");

    public static void render(GuiGraphics g) {
        Minecraft mc = Minecraft.getInstance();
        int w = mc.getWindow().getGuiScaledWidth();
        int h = mc.getWindow().getGuiScaledHeight();
        long now = System.currentTimeMillis();
        Font font = mc.font;

        // tom azulado de fita
        g.fill(0, 0, w, h, 0x14001030);

        // scanlines
        for (int y = 0; y < h; y += 2) g.fill(0, y, w, y + 1, 0x28000000);

        // vinheta
        int v = Math.max(8, h / 6);
        g.fillGradient(0, 0, w, v, 0x88000000, 0x00000000);
        g.fillGradient(0, h - v, w, h, 0x00000000, 0x88000000);
        g.fill(0, 0, 6, h, 0x55000000);
        g.fill(w - 6, 0, w, h, 0x55000000);

        // ruido estatico
        for (int i = 0; i < 40; i++) {
            int x = RNG.nextInt(w), y = RNG.nextInt(h);
            int a = 20 + RNG.nextInt(60);
            g.fill(x, y, x + 1 + RNG.nextInt(3), y + 1, (a << 24) | 0xFFFFFF);
        }

        // faixa de tracking + glitch ocasional
        int bandY = (int) ((now / 12) % (h + 40)) - 20;
        g.fill(0, bandY, w, bandY + 2, 0x22FFFFFF);
        if (RNG.nextInt(90) == 0) {
            int gy = RNG.nextInt(h);
            g.fill(0, gy, w, gy + 2 + RNG.nextInt(5), 0x55FFFFFF);
        }

        // cantos do viewfinder
        int m = 14, L = 12, c = 0x99FFFFFF;
        corner(g, m, m, L, 1, 1, c);
        corner(g, w - m, m, L, -1, 1, c);
        corner(g, m, h - m, L, 1, -1, c);
        corner(g, w - m, h - m, L, -1, -1, c);

        // caixa de foco central
        int cx = w / 2, cy = h / 2;
        g.renderOutline(cx - 14, cy - 10, 28, 20, 0x66FFFFFF);

        // OSD
        g.drawString(font, "TAPE " + CamState.tape, 20, 20, WHITE, true);
        g.drawString(font, CamState.longPlay ? "LP" : "SP", 20, h - 28, WHITE, true);

        String date = CamState.recording ? LocalDateTime.now().format(DATE) : "-- : --";
        g.drawString(font, date, w - 20 - font.width(date), 20, WHITE, true);

        long s = CamState.elapsedMs() / 1000;
        String tc = String.format("%02d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60);
        g.drawString(font, tc, w - 20 - font.width(tc), h - 28, WHITE, true);

        if (CamState.recording) {
            if ((now / 500) % 2 == 0) {
                g.fill(20, 34, 26, 40, 0xFFFF2020);
                g.drawString(font, "REC", 30, 33, 0xFFFF4040, true);
            }
        } else {
            g.drawString(font, "STBY", 20, 34, WHITE, true);
        }

        if (CamState.zoom > 1.01f) {
            String z = String.format("x%.1f", CamState.zoom);
            g.drawString(font, z, cx - font.width(z) / 2, h - 44, WHITE, true);
        }
    }

    private static void corner(GuiGraphics g, int x, int y, int len, int dx, int dy, int col) {
        g.fill(Math.min(x, x + dx * len), y, Math.max(x, x + dx * len), y + 1, col);
        g.fill(x, Math.min(y, y + dy * len), x + 1, Math.max(y, y + dy * len), col);
    }
}
