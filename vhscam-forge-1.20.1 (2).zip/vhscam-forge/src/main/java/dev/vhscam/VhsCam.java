package dev.vhscam;

import net.minecraftforge.fml.common.Mod;

@Mod(VhsCam.MODID)
public class VhsCam {
    public static final String MODID = "vhscam";

    public VhsCam() {
        // Mod somente de cliente: toda a logica esta em ClientEvents.
    }
}
