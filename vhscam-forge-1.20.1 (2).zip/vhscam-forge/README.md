# VHS Viewfinder (Forge 1.20.1 / 47.x)
Requisitos: JDK 17, Gradle 8.1.1 a 8.8 (ForgeGradle 6).
Compilar: `gradle build` -> .jar em build/libs/. Testar: `gradle runClient`.
Teclas (mudaveis em Controles): V erguer | R gravar/standby | Setas cima/baixo zoom | B fita | N SP/LP
